from django.apps import AppConfig


class AppconsultaConfig(AppConfig):
    name = 'appconsulta'
