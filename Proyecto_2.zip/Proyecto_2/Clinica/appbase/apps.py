from django.apps import AppConfig


class AppbaseConfig(AppConfig):
    name = 'appbase'
